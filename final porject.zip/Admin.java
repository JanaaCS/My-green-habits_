package mygreenhabits;

public class Admin extends User {
    public Admin() {
    }

    public Admin(int userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    public void manageUsers() {
        try {
            System.out.println("Admin can manage users.");
        } catch (Exception e) {
            System.out.println("Error managing users.");
        }
    }

    public void manageCategories() {
        try {
            System.out.println("Admin can manage categories.");
        } catch (Exception e) {
            System.out.println("Error managing categories.");
        }
    }

    public void updateDefaultPoints(Category category, int newPoints) {
        try {
            if (category == null) {
                throw new NullPointerException();
            }

            if (newPoints < 0) {
                throw new IllegalArgumentException();
            }

            category.setDefaultPoints(newPoints);
            System.out.println("Default points updated successfully.");

        } catch (Exception e) {
            System.out.println("Error updating points.");
        }
    }

    public void generateReports() {
        try {
            System.out.println("Admin report generated.");
        } catch (Exception e) {
            System.out.println("Error generating report.");
        }
    }
}

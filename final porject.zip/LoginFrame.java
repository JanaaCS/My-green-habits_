package mygreenhabits;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginFrame extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JCheckBox adminCheckBox;

    public LoginFrame() {
        setTitle("My Green Habits - Login");
        setSize(710, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(235, 248, 240));
        formPanel.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));
        

        formPanel.setPreferredSize(new Dimension(365, 450));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 8, 10, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("My Green Habits");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 32));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setForeground(Color.BLACK);

        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");

        emailLabel.setForeground(Color.BLACK);
        passwordLabel.setForeground(Color.BLACK);
        emailLabel.setFont(new Font("Serif", Font.BOLD, 17));
        passwordLabel.setFont(new Font("Serif", Font.BOLD, 17));

        emailField = new JTextField(18);
        passwordField = new JPasswordField(18);

        emailField.setFont(new Font("Serif", Font.PLAIN, 15));
        passwordField.setFont(new Font("Serif", Font.PLAIN, 15));

        adminCheckBox = new JCheckBox("Login as Admin");
        adminCheckBox.setBackground(new Color(235, 248, 240));
        adminCheckBox.setForeground(Color.BLACK);
        adminCheckBox.setFont(new Font("Serif", Font.BOLD, 15));

        loginButton = new JButton("Login");
        registerButton = new JButton("Create Account");

        styleButton(loginButton);
        styleButton(registerButton);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 8, 30, 8);
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.insets = new Insets(10, 8, 10, 8);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(emailLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(22, 8, 22, 8);
        formPanel.add(adminCheckBox, gbc);

        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(10, 8, 10, 8);

        gbc.gridx = 0;
        formPanel.add(loginButton, gbc);

        gbc.gridx = 1;
        formPanel.add(registerButton, gbc);

        mainPanel.add(formPanel, BorderLayout.WEST);
        add(mainPanel);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginFromDatabase();
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegisterFrame().setVisible(true);
                dispose();
            }
        });
    }

    private void loginFromDatabase() {
        try {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter email and password.");
                return;
            }

            if (!email.contains("@")) {
                JOptionPane.showMessageDialog(this, "Email must contain @");
                return;
            }

            String sql = """
                SELECT UserID, FirstName, LastName, Email, Password, AdminID
                FROM Users
                WHERE Email = ? AND Password = ?
            """;

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {

                pst.setString(1, email);
                pst.setString(2, password);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("UserID");
                    String firstName = rs.getString("FirstName");
                    String lastName = rs.getString("LastName");
                    String dbEmail = rs.getString("Email");
                    String dbPassword = rs.getString("Password");

                    rs.getInt("AdminID");
                    boolean isAdmin = !rs.wasNull();

                    if (adminCheckBox.isSelected()) {
                        if (isAdmin) {
                            Admin admin = new Admin(userId, firstName + " " + lastName, dbEmail, dbPassword);
                            JOptionPane.showMessageDialog(this, "Admin login successful.");
                            new AdminDashboardFrame(admin).setVisible(true);
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(this, "This account is not an admin account.");
                        }
                    } else {
                        User user = new User(userId, firstName + " " + lastName, dbEmail, dbPassword);
                        JOptionPane.showMessageDialog(this, "User login successful.");
                        new UserDashboardFrame(user).setVisible(true);
                        dispose();
                    }

                } else {
                    JOptionPane.showMessageDialog(this, "Invalid email or password.");
                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Login error: " + ex.getMessage());
        }
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(210, 245, 225));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Serif", Font.BOLD, 15));
    }

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
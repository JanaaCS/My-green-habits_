package mygreenhabits;

public class Category {
    private int categoryId;
    private String categoryName;
    private int defaultPoints;

    public Category() {
    }

    public Category(int categoryId, String categoryName, int defaultPoints) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.defaultPoints = defaultPoints;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getDefaultPoints() {
        return defaultPoints;
    }

    public void setDefaultPoints(int defaultPoints) {
        this.defaultPoints = defaultPoints;
    }

    public void addCategory() {
        try {
            if (categoryName == null || categoryName.isEmpty()) {
                throw new IllegalArgumentException();
            }

            System.out.println("Category added successfully.");

        } catch (Exception e) {
            System.out.println("Error adding category.");
        }
    }

    public void updateCategory() {
        try {
            if (categoryId <= 0) {
                throw new IllegalArgumentException();
            }

            System.out.println("Category updated successfully.");

        } catch (Exception e) {
            System.out.println("Error updating category.");
        }
    }

    public void viewCategory() {
        try {
            if (categoryName == null) {
                throw new NullPointerException();
            }

            System.out.println("Category Name: " + categoryName);
            System.out.println("Default Points: " + defaultPoints);

        } catch (Exception e) {
            System.out.println("Error viewing category.");
        }
    }
}

package mygreenhabits;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ScoreFrame extends JFrame {

    private SustainabilityScore score;
    private JLabel totalScoreLabel;
    private JLabel lastUpdatedLabel;

    public ScoreFrame(SustainabilityScore score) {
        this.score = score;

        setTitle("Sustainability Score");
        setSize(420, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new GridBagLayout());

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBackground(new Color(235, 248, 240));
        panel.setBorder(BorderFactory.createLineBorder(new Color(8, 100, 50), 2));

        JLabel titleLabel = new JLabel("Sustainability Score", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 22));
        titleLabel.setForeground(new Color(8, 100, 50));

        totalScoreLabel = new JLabel("Total Score: " + score.getTotalScore(), SwingConstants.CENTER);
        lastUpdatedLabel = new JLabel("Last Updated: " + score.getLastUpdated(), SwingConstants.CENTER);

        JButton viewButton = new JButton("View Score");
        styleButton(viewButton);

        panel.add(titleLabel);
        panel.add(totalScoreLabel);
        panel.add(lastUpdatedLabel);
        panel.add(viewButton);

        mainPanel.add(panel);
        add(mainPanel);

        viewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewScore();
            }
        });
    }

    private void viewScore() {
        try {
            score.viewScore();

            totalScoreLabel.setText("Total Score: " + score.getTotalScore());
            lastUpdatedLabel.setText("Last Updated: " + score.getLastUpdated());

            JOptionPane.showMessageDialog(this,
                    "Total Score: " + score.getTotalScore()
                    + "\nLast Updated: " + score.getLastUpdated());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error viewing score.");
        }
    }

    private void styleButton(JButton button) {
    button.setBackground(new Color(210, 245, 225));
    button.setForeground(Color.BLACK);
    button.setFont(new Font("Serif", Font.BOLD, 13));
}

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
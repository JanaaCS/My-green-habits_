package mygreenhabits;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;

public class AddActivityFrame extends JFrame {

    private User user;
    private ActivityManager activityManager;
    private SustainabilityScore score;

    private JComboBox<String> activityBox;
    private JTextField dateField;
    private JTextField pointsField;
    private JButton calculateButton;
    private JButton addButton;

    public AddActivityFrame(User user, ActivityManager activityManager, SustainabilityScore score) {
        this.user = user;
        this.activityManager = activityManager;
        this.score = score;

        setTitle("Add Activity");
        setSize(520, 380);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new GridBagLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(235, 248, 240));
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(8, 100, 50), 2));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Add Green Activity", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 22));
        titleLabel.setForeground(Color.BLACK);

        JLabel activityLabel = new JLabel("Activity:");
        JLabel dateLabel = new JLabel("Date:");
        JLabel pointsLabel = new JLabel("Points:");

        activityLabel.setForeground(Color.BLACK);
        dateLabel.setForeground(Color.BLACK);
        pointsLabel.setForeground(Color.BLACK);

        activityBox = new JComboBox<>(new String[]{
            "Plastic Recycling",
            "Paper Recycling",
            "Glass Recycling",
            "Can Recycling",
            "Cardboard Recycling",
            "Battery Recycling",
            "Bottle Recycling",
            "Metal Recycling",
            "Clothes Recycling",
            "Book Recycling",
            "Turn Off Lights",
            "Use LED Bulbs",
            "Unplug Devices",
            "Use Natural Light",
            "Save AC Energy",
            "Reduce Heater Use",
            "Close Windows",
            "Use Fan",
            "Power Saving Mode",
            "Short Device Use"
        });

        dateField = new JTextField("2026-05-18", 15);

        pointsField = new JTextField(15);
        pointsField.setEditable(false);

        calculateButton = new JButton("Calculate Points");
        addButton = new JButton("Add Activity");

        styleButton(calculateButton);
        styleButton(addButton);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(activityLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(activityBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(dateLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(dateField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(pointsLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(pointsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(calculateButton, gbc);

        gbc.gridx = 1;
        formPanel.add(addButton, gbc);

        mainPanel.add(formPanel);
        add(mainPanel);

        calculateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculatePoints();
            }
        });

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addActivityToDatabase();
            }
        });
    }

    private void calculatePoints() {
        try {
            String selectedActivity = activityBox.getSelectedItem().toString();

            int points = getActivityPointsFromDatabase(selectedActivity);

            pointsField.setText(String.valueOf(points));

            if (isRecyclingActivity(selectedActivity)) {
                RecyclingActivity recycling = new RecyclingActivity();
                recycling.calculateRecyclingPoints();
            } else {
                EnergySavingActivity energy = new EnergySavingActivity();
                energy.calculateEnergyPoints();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error calculating points: " + e.getMessage());
        }
    }

    private int getActivityPointsFromDatabase(String activityType) throws Exception {
        String sql = """
            SELECT Points
            FROM Activity
            WHERE ActivityType = ?
            ORDER BY ActivityID DESC
            LIMIT 1
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, activityType);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("Points");
                }
            }
        }

        throw new Exception("Activity points not found.");
    }

    private void addActivityToDatabase() {
        try {
            String selectedActivity = activityBox.getSelectedItem().toString();
            String dateText = dateField.getText().trim();

            if (dateText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter the date.");
                return;
            }

            if (pointsField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please calculate points first.");
                return;
            }

            int points = Integer.parseInt(pointsField.getText());
            int categoryId = getCategoryId(selectedActivity);

            Date sqlDate;

            try {
                sqlDate = Date.valueOf(dateText);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, "Date format must be YYYY-MM-DD.");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {

                int newActivityId = getNextActivityId(conn);

                String sql = """
                    INSERT INTO Activity
                    (ActivityID, Date, ActivityType, Points, UserID, CategoryID, ManagerID)
                    VALUES (?, ?, ?, ?, ?, ?, NULL)
                """;

                try (PreparedStatement pst = conn.prepareStatement(sql)) {
                    pst.setInt(1, newActivityId);
                    pst.setDate(2, sqlDate);
                    pst.setString(3, selectedActivity);
                    pst.setInt(4, points);
                    pst.setInt(5, user.getUserId());
                    pst.setInt(6, categoryId);

                    pst.executeUpdate();
                }

                if (isRecyclingActivity(selectedActivity)) {
                    insertRecyclingActivity(conn, newActivityId, selectedActivity);
                } else {
                    insertEnergySavingActivity(conn, newActivityId, selectedActivity);
                }

                Activity activity;

                if (isRecyclingActivity(selectedActivity)) {
                    activity = new RecyclingActivity(
                            newActivityId,
                            user.getUserId(),
                            categoryId,
                            selectedActivity,
                            dateText,
                            points
                    );
                } else {
                    activity = new EnergySavingActivity(
                            newActivityId,
                            user.getUserId(),
                            categoryId,
                            selectedActivity,
                            dateText,
                            points
                    );
                }

                Category category = new Category(categoryId, getCategoryName(categoryId), points);

                activityManager.createActivity(activity, user, category);
                score.calculateScore(points);

                ExportData.exportData(
                        selectedActivity,
                        "Activity added by user: " + user.getName(),
                        points,
                        dateText
                );

                JOptionPane.showMessageDialog(this, "Activity added successfully to database and exported to file.");
                dispose();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error adding activity: " + e.getMessage());
        }
    }

    private int getNextActivityId(Connection conn) throws Exception {
        String sql = "SELECT IFNULL(MAX(ActivityID), 0) + 1 AS NewID FROM Activity";

        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("NewID");
            }
        }

        return 1;
    }

    private boolean isRecyclingActivity(String activity) {
        return activity.contains("Recycling")
                || activity.equals("Can Recycling")
                || activity.equals("Cardboard Recycling")
                || activity.equals("Battery Recycling")
                || activity.equals("Bottle Recycling")
                || activity.equals("Metal Recycling")
                || activity.equals("Clothes Recycling")
                || activity.equals("Book Recycling");
    }

    private int getCategoryId(String activity) {
        if (isRecyclingActivity(activity)) {
            return 1;
        } else {
            return 2;
        }
    }

    private String getCategoryName(int categoryId) {
        if (categoryId == 1) {
            return "Recycling";
        } else {
            return "Energy Saving";
        }
    }

    private void insertRecyclingActivity(Connection conn, int activityId, String activityType) throws Exception {
        String materialType = activityType.replace(" Recycling", "");

        String sql = """
            INSERT INTO RecyclingActivity (ActivityID, MaterialType)
            VALUES (?, ?)
        """;

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, activityId);
            pst.setString(2, materialType);
            pst.executeUpdate();
        }
    }

    private void insertEnergySavingActivity(Connection conn, int activityId, String activityType) throws Exception {
        String sql = """
            INSERT INTO EnergySavingActivity (ActivityID, SavingMethod)
            VALUES (?, ?)
        """;

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, activityId);
            pst.setString(2, activityType);
            pst.executeUpdate();
        }
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(210, 245, 225));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Serif", Font.BOLD, 13));
    }

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
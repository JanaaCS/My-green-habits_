package mygreenhabits;

public class RecyclingActivity extends Activity {
    public RecyclingActivity() {
    }

    public RecyclingActivity(int activityId, int userId, int categoryId, String activityType, String date, int points) {
        super(activityId, userId, categoryId, activityType, date, points);
    }

    public void calculateRecyclingPoints() {
        try {
            setPoints(15);
            System.out.println("Recycling points calculated: " + getPoints());
        } catch (Exception e) {
            System.out.println("Error calculating recycling points.");
        }
    }
}

package mygreenhabits;

public class EnergySavingActivity extends Activity {
    public EnergySavingActivity() {
    }

    public EnergySavingActivity(int activityId, int userId, int categoryId, String activityType, String date, int points) {
        super(activityId, userId, categoryId, activityType, date, points);
    }

    public void calculateEnergyPoints() {
        try {
            setPoints(10);
            System.out.println("Energy saving points calculated: " + getPoints());
        } catch (Exception e) {
            System.out.println("Error calculating energy points.");
        }
    }
}

package mygreenhabits;

public class Activity {
    private int activityId;
    private int userId;
    private int categoryId;
    private String activityType;
    private String date;
    private int points;

    public Activity() {
    }

    public Activity(int activityId, int userId, int categoryId, String activityType, String date, int points) {
        this.activityId = activityId;
        this.userId = userId;
        this.categoryId = categoryId;
        this.activityType = activityType;
        this.date = date;
        this.points = points;
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void addActivity() {
        try {
            if (activityType == null || activityType.isEmpty()) {
                throw new IllegalArgumentException("Activity type cannot be empty.");
            }

            if (points < 0) {
                throw new IllegalArgumentException("Points cannot be negative.");
            }

            System.out.println("Activity added successfully.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void editActivity() {
        try {
            if (activityId <= 0) {
                throw new IllegalArgumentException("Invalid activity ID.");
            }

            System.out.println("Activity updated successfully.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void deleteActivity() {
        try {
            if (activityId <= 0) {
                throw new IllegalArgumentException("Invalid activity ID.");
            }

            System.out.println("Activity deleted successfully.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void viewActivity() {
        try {
            if (activityType == null || activityType.isEmpty()) {
                throw new NullPointerException("No activity data found.");
            }

            System.out.println("Activity Type: " + activityType);
            System.out.println("Date: " + date);
            System.out.println("Points: " + points);

        } catch (NullPointerException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

package mygreenhabits;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserDashboardFrame extends JFrame {

    private User user;
    private ActivityManager activityManager;
    private SustainabilityScore score;

    public UserDashboardFrame(User user) {
        this.user = user;
        this.activityManager = new ActivityManager();
        this.score = new SustainabilityScore(user.getUserId(), 0, "2026-05-18");

        setTitle("User Dashboard");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new GridBagLayout());

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBackground(new Color(235, 248, 240));
        panel.setBorder(BorderFactory.createLineBorder(new Color(8, 100, 50), 2));
        panel.setPreferredSize(new Dimension(330, 280));

        JLabel titleLabel = new JLabel("Welcome, " + user.getName(), SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 22));
        titleLabel.setForeground(new Color(8, 100, 50));

        JButton addActivityButton = new JButton("Add Activity");
        JButton manageActivityButton = new JButton("Manage Activities");
        JButton scoreButton = new JButton("View Sustainability Score");
        JButton logoutButton = new JButton("Logout");

        styleButton(addActivityButton);
        styleButton(manageActivityButton);
        styleButton(scoreButton);
        styleButton(logoutButton);

        panel.add(titleLabel);
        panel.add(addActivityButton);
        panel.add(manageActivityButton);
        panel.add(scoreButton);
        panel.add(logoutButton);

        mainPanel.add(panel);
        add(mainPanel);

        addActivityButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddActivityFrame(user, activityManager, score).setVisible(true);
            }
        });

        manageActivityButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ManageActivitiesFrame(activityManager).setVisible(true);
            }
        });

        scoreButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ScoreFrame(score).setVisible(true);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                user.logout();
                new LoginFrame().setVisible(true);
                dispose();
            }
        });
    }

    private void styleButton(JButton button) {
    button.setBackground(new Color(210, 245, 225));
    button.setForeground(Color.BLACK);
    button.setFont(new Font("Serif", Font.BOLD, 13));
}

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}

package mygreenhabits;

import java.io.FileWriter;

public class ExportData {

    public static void exportData(String type, String description, int points, String date) {

        try {
            FileWriter writer = new FileWriter("activities.txt", true);

            writer.write("Type: " + type + "\n");
            writer.write("Description: " + description + "\n");
            writer.write("Points: " + points + "\n");
            writer.write("Date: " + date + "\n");
            writer.write("------------------------\n");

            writer.close();

            System.out.println("Data Exported Successfully");

        } catch (Exception e) {
            System.out.println("Export error: " + e.getMessage());
        }
    }
}
package mygreenhabits;

import java.util.ArrayList;

public class ActivityManager {
    private ArrayList<Activity> activities = new ArrayList<>();

    public void createActivity(Activity activity, User user, Category category) {
        try {
            if (activity == null) {
                throw new NullPointerException("Activity object cannot be null.");
            }

            if (user == null) {
                throw new NullPointerException("User object cannot be null.");
            }

            if (category == null) {
                throw new NullPointerException("Category object cannot be null.");
            }

            if (activity.getActivityType() == null || activity.getActivityType().isEmpty()) {
                throw new IllegalArgumentException("Activity type cannot be empty.");
            }

            if (activity.getPoints() < 0) {
                throw new IllegalArgumentException("Points cannot be negative.");
            }

            activity.setUserId(user.getUserId());
            activity.setCategoryId(category.getCategoryId());
            activities.add(activity);

            System.out.println("Activity created successfully.");

        } catch (NullPointerException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (Exception e) {
            System.out.println("Unexpected error while creating activity.");
        }
    }

    public void readActivities() {
        try {
            if (activities == null || activities.isEmpty()) {
                throw new IllegalStateException("No activities found.");
            }

            for (Activity activity : activities) {
                System.out.println("----------------------");
                System.out.println("Activity ID: " + activity.getActivityId());
                System.out.println("User ID: " + activity.getUserId());
                System.out.println("Category ID: " + activity.getCategoryId());
                activity.viewActivity();
            }

        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (Exception e) {
            System.out.println("Unexpected error while reading activities.");
        }
    }

    public void updateActivity(int activityId, String newActivityType, String newDate, int newPoints) {
        try {
            if (activityId <= 0) {
                throw new IllegalArgumentException("Invalid activity ID.");
            }

            if (newActivityType == null || newActivityType.isEmpty()) {
                throw new IllegalArgumentException("Activity type cannot be empty.");
            }

            if (newDate == null || newDate.isEmpty()) {
                throw new IllegalArgumentException("Date cannot be empty.");
            }

            if (newPoints < 0) {
                throw new IllegalArgumentException("Points cannot be negative.");
            }

            for (Activity activity : activities) {
                if (activity.getActivityId() == activityId) {
                    activity.setActivityType(newActivityType);
                    activity.setDate(newDate);
                    activity.setPoints(newPoints);

                    System.out.println("Activity updated successfully.");
                    return;
                }
            }

            throw new IllegalArgumentException("Activity not found.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (Exception e) {
            System.out.println("Unexpected error while updating activity.");
        }
    }

    public void deleteActivity(int activityId) {
        try {
            if (activityId <= 0) {
                throw new IllegalArgumentException("Invalid activity ID.");
            }

            for (Activity activity : activities) {
                if (activity.getActivityId() == activityId) {
                    activities.remove(activity);

                    System.out.println("Activity deleted successfully.");
                    return;
                }
            }

            throw new IllegalArgumentException("Activity not found.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (Exception e) {
            System.out.println("Unexpected error while deleting activity.");
        }
    }
    
    public ArrayList<Activity> getActivities() {
    return activities;
}
}

package mygreenhabits;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegisterFrame extends JFrame {

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton createButton;
    private JButton backButton;

    public RegisterFrame() {
        setTitle("Create Account");
        setSize(500, 430);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new GridBagLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(235, 248, 240));
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(8, 100, 50), 2));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Create New Account");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 23));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setForeground(Color.BLACK);

        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");

        firstNameLabel.setForeground(Color.BLACK);
        lastNameLabel.setForeground(Color.BLACK);
        emailLabel.setForeground(Color.BLACK);
        passwordLabel.setForeground(Color.BLACK);
        confirmPasswordLabel.setForeground(Color.BLACK);

        firstNameField = new JTextField(18);
        lastNameField = new JTextField(18);
        emailField = new JTextField(18);
        passwordField = new JPasswordField(18);
        confirmPasswordField = new JPasswordField(18);

        createButton = new JButton("Create Account");
        backButton = new JButton("Back to Login");

        styleButton(createButton);
        styleButton(backButton);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(firstNameLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(lastNameLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(emailLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(confirmPasswordLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(confirmPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(createButton, gbc);

        gbc.gridx = 1;
        formPanel.add(backButton, gbc);

        mainPanel.add(formPanel);
        add(mainPanel);

        createButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createAccount();
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });
    }

    private void createAccount() {
    try {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()
                || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {

            int newUserId = 1;

            String getMaxIdSql = "SELECT IFNULL(MAX(UserID), 0) + 1 AS NewID FROM Users";

            try (PreparedStatement idStmt = conn.prepareStatement(getMaxIdSql);
                 ResultSet rs = idStmt.executeQuery()) {

                if (rs.next()) {
                    newUserId = rs.getInt("NewID");
                }
            }

            String sql = """
                INSERT INTO Users (UserID, FirstName, LastName, Email, Password, AdminID)
                VALUES (?, ?, ?, ?, ?, NULL)
            """;

            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setInt(1, newUserId);
                pst.setString(2, firstName);
                pst.setString(3, lastName);
                pst.setString(4, email);
                pst.setString(5, password);

                pst.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Account created successfully.");

            new LoginFrame().setVisible(true);
            dispose();
        }

    } catch (java.sql.SQLIntegrityConstraintViolationException e) {
        JOptionPane.showMessageDialog(this, "This email already exists.");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Registration error: " + ex.getMessage());
    }
}

    private void styleButton(JButton button) {
        button.setBackground(new Color(210, 245, 225));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Serif", Font.BOLD, 13));
    }

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
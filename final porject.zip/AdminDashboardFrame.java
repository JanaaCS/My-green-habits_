package mygreenhabits;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminDashboardFrame extends JFrame {

    private Admin admin;
    private JTable table;
    private DefaultTableModel tableModel;

    private JButton viewUsersButton;
    private JButton viewActivitiesButton;
    private JButton manageActivitiesButton;
    private JButton logoutButton;

    public AdminDashboardFrame(Admin admin) {
        this.admin = admin;

        setTitle("Admin Dashboard");
        setSize(850, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(235, 248, 240));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Admin Dashboard - Welcome " + admin.getName(), SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 26));
        titleLabel.setForeground(Color.BLACK);

        topPanel.add(titleLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(235, 248, 240));

        viewUsersButton = new JButton("View All Users");
        viewActivitiesButton = new JButton("View All Activities");
        manageActivitiesButton = new JButton("Manage Activities");
        logoutButton = new JButton("Logout");

        styleButton(viewUsersButton);
        styleButton(viewActivitiesButton);
        styleButton(manageActivitiesButton);
        styleButton(logoutButton);

        buttonPanel.add(viewUsersButton);
        buttonPanel.add(viewActivitiesButton);
        buttonPanel.add(manageActivitiesButton);
        buttonPanel.add(logoutButton);

        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        table.setFont(new Font("Serif", Font.PLAIN, 14));
        table.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 25, 25));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        viewUsersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAllUsers();
            }
        });

        viewActivitiesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAllActivities();
            }
        });

        manageActivitiesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                manageActivities();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                admin.logout();
                new LoginFrame().setVisible(true);
                dispose();
            }
        });

        viewAllUsers();
    }

    private void viewAllUsers() {
        try {
            tableModel.setRowCount(0);
            tableModel.setColumnCount(0);

            tableModel.addColumn("User ID");
            tableModel.addColumn("First Name");
            tableModel.addColumn("Last Name");
            tableModel.addColumn("Email");
            tableModel.addColumn("Admin ID");

            String sql = """
                SELECT UserID, FirstName, LastName, Email, AdminID
                FROM Users
                ORDER BY UserID
            """;

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    Object adminIdValue;

                    int adminId = rs.getInt("AdminID");
                    if (rs.wasNull()) {
                        adminIdValue = "User";
                    } else {
                        adminIdValue = adminId;
                    }

                    tableModel.addRow(new Object[]{
                        rs.getInt("UserID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        adminIdValue
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    private void viewAllActivities() {
        try {
            tableModel.setRowCount(0);
            tableModel.setColumnCount(0);

            tableModel.addColumn("Activity ID");
            tableModel.addColumn("Date");
            tableModel.addColumn("Activity Type");
            tableModel.addColumn("Points");
            tableModel.addColumn("User ID");
            tableModel.addColumn("Category ID");

            String sql = """
                SELECT ActivityID, Date, ActivityType, Points, UserID, CategoryID
                FROM Activity
                ORDER BY ActivityID
            """;

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    tableModel.addRow(new Object[]{
                        rs.getInt("ActivityID"),
                        rs.getDate("Date"),
                        rs.getString("ActivityType"),
                        rs.getInt("Points"),
                        rs.getInt("UserID"),
                        rs.getInt("CategoryID")
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading activities: " + e.getMessage());
        }
    }

    private void manageActivities() {
        JDialog dialog = new JDialog(this, "Manage Activities", true);
        dialog.setSize(750, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        DefaultTableModel activityModel = new DefaultTableModel();
        JTable activityTable = new JTable(activityModel);
        activityTable.setRowHeight(25);
        activityTable.setFont(new Font("Serif", Font.PLAIN, 14));

        activityModel.addColumn("Activity ID");
        activityModel.addColumn("Date");
        activityModel.addColumn("Activity Type");
        activityModel.addColumn("Points");
        activityModel.addColumn("User ID");
        activityModel.addColumn("Category ID");

        loadActivitiesIntoTable(activityModel);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.setBackground(new Color(235, 248, 240));

        JTextField activityIdField = new JTextField(8);
        JTextField newPointsField = new JTextField(8);

        JButton updateButton = new JButton("Update Points");

        styleButton(updateButton);

        JLabel activityIdLabel = new JLabel("Activity ID:");
        JLabel newPointsLabel = new JLabel("New Points:");

        activityIdLabel.setForeground(Color.BLACK);
        newPointsLabel.setForeground(Color.BLACK);

        bottomPanel.add(activityIdLabel);
        bottomPanel.add(activityIdField);
        bottomPanel.add(newPointsLabel);
        bottomPanel.add(newPointsField);
        bottomPanel.add(updateButton);

        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int activityId = Integer.parseInt(activityIdField.getText().trim());
                    int newPoints = Integer.parseInt(newPointsField.getText().trim());

                    if (activityId <= 0) {
                        JOptionPane.showMessageDialog(dialog, "Invalid Activity ID.");
                        return;
                    }

                    if (newPoints < 0) {
                        JOptionPane.showMessageDialog(dialog, "Points cannot be negative.");
                        return;
                    }

                    String getTypeSql = """
                        SELECT ActivityType
                        FROM Activity
                        WHERE ActivityID = ?
                    """;

                    String activityType = null;

                    try (Connection conn = DatabaseConnection.getConnection();
                         PreparedStatement getTypeStmt = conn.prepareStatement(getTypeSql)) {

                        getTypeStmt.setInt(1, activityId);

                        try (ResultSet rs = getTypeStmt.executeQuery()) {
                            if (rs.next()) {
                                activityType = rs.getString("ActivityType");
                            } else {
                                JOptionPane.showMessageDialog(dialog, "Activity ID not found.");
                                return;
                            }
                        }

                        String updateSql = """
                            UPDATE Activity
                            SET Points = ?
                            WHERE ActivityType = ?
                        """;

                        try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                            updateStmt.setInt(1, newPoints);
                            updateStmt.setString(2, activityType);

                            int rows = updateStmt.executeUpdate();

                            JOptionPane.showMessageDialog(dialog,
                                    "Points updated successfully for all " + activityType + " activities."
                                    + "\nUpdated rows: " + rows);

                            activityModel.setRowCount(0);
                            loadActivitiesIntoTable(activityModel);

                            viewAllActivities();
                        }
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Activity ID and points must be numbers.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error updating activity: " + ex.getMessage());
                }
            }
        });

        dialog.add(new JScrollPane(activityTable), BorderLayout.CENTER);
        dialog.add(bottomPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void loadActivitiesIntoTable(DefaultTableModel model) {
        try {
            String sql = """
                SELECT ActivityID, Date, ActivityType, Points, UserID, CategoryID
                FROM Activity
                ORDER BY ActivityID
            """;

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("ActivityID"),
                        rs.getDate("Date"),
                        rs.getString("ActivityType"),
                        rs.getInt("Points"),
                        rs.getInt("UserID"),
                        rs.getInt("CategoryID")
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading activities: " + e.getMessage());
        }
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(210, 245, 225));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Serif", Font.BOLD, 14));
    }

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
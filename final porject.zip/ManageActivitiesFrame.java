package mygreenhabits;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class ManageActivitiesFrame extends JFrame {

    private ActivityManager activityManager;
    private JTable activityTable;
    private DefaultTableModel tableModel;

    private JTextField idField;
    private JTextField typeField;
    private JTextField dateField;
    private JTextField pointsField;

    public ManageActivitiesFrame(ActivityManager activityManager) {
        this.activityManager = activityManager;

        setTitle("Manage Activities");
        setSize(750, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel mainPanel = new BackgroundPanel("/mygreenhabits/logo2.jpeg");
        mainPanel.setLayout(new BorderLayout());

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(new Color(235, 248, 240));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Manage Activities", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 22));
        titleLabel.setForeground(new Color(8, 100, 50));

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Activity ID");
        tableModel.addColumn("User ID");
        tableModel.addColumn("Category ID");
        tableModel.addColumn("Activity Type");
        tableModel.addColumn("Date");
        tableModel.addColumn("Points");

        activityTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(activityTable);

        JPanel editPanel = new JPanel(new GridLayout(2, 4, 8, 8));
        editPanel.setBackground(new Color(235, 248, 240));

        idField = new JTextField();
        typeField = new JTextField();
        dateField = new JTextField();
        pointsField = new JTextField();

        editPanel.add(new JLabel("Activity ID:"));
        editPanel.add(new JLabel("New Type:"));
        editPanel.add(new JLabel("New Date:"));
        editPanel.add(new JLabel("New Points:"));

        editPanel.add(idField);
        editPanel.add(typeField);
        editPanel.add(dateField);
        editPanel.add(pointsField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(235, 248, 240));

        JButton refreshButton = new JButton("View");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");

        styleButton(refreshButton);
        styleButton(updateButton);
        styleButton(deleteButton);

        buttonPanel.add(refreshButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        contentPanel.add(titleLabel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(editPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshTable();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateActivity();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteActivity();
            }
        });

        refreshTable();
    }

    private void refreshTable() {
        try {
            tableModel.setRowCount(0);

            for (Activity activity : activityManager.getActivities()) {
                tableModel.addRow(new Object[]{
                    activity.getActivityId(),
                    activity.getUserId(),
                    activity.getCategoryId(),
                    activity.getActivityType(),
                    activity.getDate(),
                    activity.getPoints()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error viewing activities.");
        }
    }

    private void updateActivity() {
        try {
            int id = Integer.parseInt(idField.getText());
            String type = typeField.getText();
            String date = dateField.getText();
            int points = Integer.parseInt(pointsField.getText());

            activityManager.updateActivity(id, type, date, points);
            refreshTable();

            JOptionPane.showMessageDialog(this, "Activity updated successfully.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID and points must be numbers.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating activity.");
        }
    }

    private void deleteActivity() {
        try {
            int id = Integer.parseInt(idField.getText());

            activityManager.deleteActivity(id);
            refreshTable();

            JOptionPane.showMessageDialog(this, "Activity deleted successfully.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Activity ID must be a number.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error deleting activity.");
        }
    }

    private void styleButton(JButton button) {
    button.setBackground(new Color(210, 245, 225));
    button.setForeground(Color.BLACK);
    button.setFont(new Font("Serif", Font.BOLD, 13));
}

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
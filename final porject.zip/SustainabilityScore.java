package mygreenhabits;

public class SustainabilityScore {
    private int userId;
    private int totalScore;
    private String lastUpdated;

    public SustainabilityScore() {
    }

    public SustainabilityScore(int userId, int totalScore, String lastUpdated) {
        this.userId = userId;
        this.totalScore = totalScore;
        this.lastUpdated = lastUpdated;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public void calculateScore(int points) {
        try {
            if (points < 0) {
                throw new IllegalArgumentException();
            }

            totalScore += points;

        } catch (Exception e) {
            System.out.println("Error calculating score.");
        }
    }

    public void updateScore(int newScore) {
        try {
            if (newScore < 0) {
                throw new IllegalArgumentException();
            }

            totalScore = newScore;

        } catch (Exception e) {
            System.out.println("Error updating score.");
        }
    }

    public void viewScore() {
        try {
            System.out.println("Total Sustainability Score: " + totalScore);
            System.out.println("Last Updated: " + lastUpdated);
        } catch (Exception e) {
            System.out.println("Error viewing score.");
        }
    }
}
